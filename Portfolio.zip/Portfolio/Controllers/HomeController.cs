using Microsoft.AspNetCore.Mvc;
using Portfolio.Models;
using System.Diagnostics;

namespace Portfolio.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;




        public IActionResult Index()
        {
            ListaProyecto ListaP = new ListaProyecto
            {
                proyecto = new List<Proyectos>

                {
                    new Proyectos
                {
                    Titulo = "Amazon",
                    Descripcion = "E-Commerce realizado en ASP.NET Core",
                    Link = "https://amazon.com",
                    ImagenURL = "/imagenes/amazon.png"
                },
                    new Proyectos
                {
                    Titulo = "New York Times",
                    Descripcion = "P�gina de noticias en React",
                    Link = "https://nytimes.com",
                    ImagenURL = "/imagenes/nyt.png"
                },
                    new Proyectos
                {
                    Titulo = "Reddit",
                    Descripcion = "Red social para compartir en comunidades",
                    Link = "https://reddit.com",
                    ImagenURL = "/imagenes/reddit.png"
                },
                    new Proyectos
                {
                    Titulo = "Steam",
                    Descripcion = "Tienda en l�nea para comprar videojuegos",
                    Link = "https://store.steampowered.com",
                    ImagenURL = "/imagenes/steam.png"
                },
                }
            };







            Portfolios p = new Portfolios
            {
                persona = new Persona { Nombre = "Alberto", Prefil = "Trabajador social de la vida", edad = 18 },
                proyectos = ListaP
            };

            return View(p);
        }


    }
}
