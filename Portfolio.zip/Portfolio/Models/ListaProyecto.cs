﻿namespace Portfolio.Models
{
    public class ListaProyecto
    {
        public List<Proyectos> proyecto { get; set; }=new List<Proyectos>();
    }
}
