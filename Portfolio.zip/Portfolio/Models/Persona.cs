﻿namespace Portfolio.Models
{
    public class Persona
    {
        public string Nombre { get; set; }
        public string Prefil { get; set; }
        public int edad { get; set; }
    }
}
