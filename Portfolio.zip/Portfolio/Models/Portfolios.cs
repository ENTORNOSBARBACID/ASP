﻿namespace Portfolio.Models
{
    public class Portfolios
    {
        public Persona persona { get; set; }
        public ListaProyecto proyectos { get; set; }
    }
}
