﻿namespace Portfolio.Models
{
   


        public class Proyectos{
        
            public string Titulo { get; set; }
            public string Descripcion { get; set; }
            public string  Link { get; set; }
            public string ImagenURL { get; set; }
            }
}
        
    

