using EjercicioTaller.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace EjercicioTaller.Controllers
{
    public class HomeController : Controller { 

        public IActionResult Index()
        {
            return View();
        }
    }
}
