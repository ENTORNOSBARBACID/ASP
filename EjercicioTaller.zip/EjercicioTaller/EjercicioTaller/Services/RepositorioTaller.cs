﻿namespace EjercicioTaller.Services
{
    public class RepositorioTaller
    {

    }
}
