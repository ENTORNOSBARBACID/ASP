﻿namespace EjercicioTaller.Models
{
    public class Dueño:Persona
    {
        public Direccion direccion { get; set; }
    }
}
