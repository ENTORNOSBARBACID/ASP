﻿namespace EjercicioTaller.Models
{
    public class Mecanico:Persona
    {
        public string fecha_alta { get; set; }
        public string foto { get; set; }
    }
}
