﻿namespace EjercicioTaller.Models
{
    public class Direccion
    {
        public string calle { get; set; }
        public int direccion { get; set; }
        public int codigoPostal {  get; set; }
        public string provincia {  get; set; }

    }
}
