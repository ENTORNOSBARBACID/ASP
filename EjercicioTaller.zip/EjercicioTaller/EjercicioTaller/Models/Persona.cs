﻿namespace EjercicioTaller.Models
{
    public class Persona
    {
        public string nombre {  get; set; }
        public string apellido { get; set; }
        public string DNI { get; set; }
        public string email { get; set; }
        public string telefono { get; set; }
    }
}
